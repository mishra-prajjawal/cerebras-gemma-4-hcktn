# Skill: multi-agent orchestration (the Cerebras speed flex)

The moat: on Cerebras you can run a **whole room of agents in real time** because each call
is ~milliseconds. The pattern that wins:

1. **Fan out** N specialist agents with `asyncio.gather` (bounded by a semaphore).
2. Each agent returns a **strict typed contract** (no free text between agents).
3. **Fan in** to a judge/moderator/synthesizer agent that ranks or reconciles.
4. Audit every hop; surface total wall-clock + tokens/sec in the UI.

Rules: bounded concurrency, bounded queues, no unbounded growth, no recursion. Each agent has
exactly one job. Treat the swarm as a pipeline of pure typed steps.
