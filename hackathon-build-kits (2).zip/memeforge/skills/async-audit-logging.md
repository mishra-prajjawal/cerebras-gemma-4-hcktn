# Skill: async audit logging (verified, predictable I/O)

Every process step emits exactly one structured JSON record via the `@audited` decorator:
`{agent, inputs_hash, outputs_hash, status, latency_ms}`.

- Hash inputs/outputs (sha256 of canonical JSON) so runs are reproducible and diffable.
- One record per step, success or failure (`finally` block).
- Never let logging raise into the hot path.
- Logs are the demo's credibility layer: replay them to prove the system is deterministic.
