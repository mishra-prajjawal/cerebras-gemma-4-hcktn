# Skill: NASA Power of 10, adapted for async Python

1. Simple control flow; **no recursion**.
2. **Bounded loops** — every loop has a provable upper bound (assert it).
3. **No unbounded memory growth** — bounded `asyncio.Queue`, LRU caches, capped lists.
4. Functions <= ~60 lines, one job each.
5. **>= 2 assertions per function** (preconditions + postconditions).
6. Declare data in the smallest possible scope.
7. **Check every return value**; never ignore an error.
8. Limit indirection (one level); no dynamic attribute magic / kwargs passthrough.
9. No bare `except:` — catch typed errors; re-raise after logging.
10. **Zero warnings**: `mypy --strict`, `ruff`, `pyright` all clean.
