# Skill: Cerebras inference via the OpenAI SDK

Cerebras is **fully OpenAI-compatible**. Use the official `openai` SDK and just point it
at the Cerebras base URL. Only the API key changes between machines.

## Client
```python
from openai import AsyncOpenAI
client = AsyncOpenAI(
    api_key=os.environ["CEREBRAS_API_KEY"],
    base_url="https://api.cerebras.ai/v1",   # OpenAI-compatible endpoint
)
resp = await client.chat.completions.create(
    model="gemma-4-31b",
    messages=[{"role": "user", "content": "hi"}],
    max_completion_tokens=256,
    extra_body={"reasoning_effort": "none"},  # Cerebras-only param -> extra_body
)
```

## Rules
- One shared `AsyncOpenAI` client for the whole app (connection reuse).
- Every call goes through the token-bucket limiter: **100 RPM / 100K TPM**.
- `reasoning_effort` is Cerebras-specific; pass it through `extra_body`, not as a top-level kwarg.
- Limits: 5K max sequence / 32K max context. Keep prompts tight; speed is the whole point.
- `resp.usage.completion_tokens` + wall time => tokens/sec (your viral speed flex).
- Version 2 of the API becomes default 2026-07-21 with stricter schema validation; we
  already satisfy it (see structured-outputs skill).
