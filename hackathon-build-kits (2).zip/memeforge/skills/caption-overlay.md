# Skill: caption overlay (render.py)

Turn the winning caption into a shareable image:
- Use Pillow; classic top/bottom impact text, white fill + black stroke, auto-wrap.
- Downscale to <= 1080px long edge for fast mobile sharing.
- Return base64 jpeg so the UI can show + download in one tap.
- Keep this step pure + synchronous; it does no model calls.
