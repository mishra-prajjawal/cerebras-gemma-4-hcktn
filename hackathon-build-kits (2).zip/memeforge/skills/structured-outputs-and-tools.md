# Skill: strict structured outputs + tool calling (Cerebras)

Guaranteed JSON that matches your schema. Required for reliable agent hand-offs.

## Strict mode (constrained decoding)
```python
response_format = {
  "type": "json_schema",
  "json_schema": {
    "name": "MyModel",
    "strict": True,
    "schema": {... , "additionalProperties": False},  # REQUIRED on EVERY object
  },
}
```
- **Generate the schema FROM the Pydantic model** (`model.model_json_schema()`), then inject
  `additionalProperties: False`. Never hand-write a parallel schema — it drifts.
- Strict mode requires every property be listed in `required`. Avoid optional fields; use
  defaults + sentinels instead.
- Validate the returned string with `Model.model_validate_json(...)`. Fail closed on error.

## Tool calling
- Same discipline: `strict: True` + `additionalProperties: False` on tool parameter schemas.
- Prefer structured outputs for agent-to-agent contracts; use tools for real side-effects.
