# Skill: multimodal (image + text -> text) on Gemma 4

Gemma 4 on Cerebras accepts **text + images in, text out**. No audio.

## Sending an image (OpenAI content-block format)
```python
messages = [{"role": "user", "content": [
    {"type": "text", "text": "What is in this image?"},
    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
]}]
```
- Downscale before encoding (long edge ~768px). Smaller images = faster + cheaper tokens.
- One thought per call: extract structured facts from the image, then reason in a 2nd call.
- Always pair the image with a strict schema so the vision step returns typed data.
