# Skill: the People's Choice share loop

Track 2 is won on **impressions**, not just quality. Engineer the share loop:

1. **Speed is the hook** — lead every clip/post with the on-screen timer: "6 comedians, 1
   image, 0.9s". The speed is the novelty GPUs cannot match.
2. **One-tap share** — output is a finished meme image (see render.py), not raw text.
3. **Build-in-public** — post the writers'-room race as a video; tag @Cerebras and
   @googlegemma in the submission post (required for Track 2).
4. **Loopable** — let viewers drop their own photo and watch the room roast it live.
5. Keep it SFW and good-natured; offensive humor kills reshare reach.
