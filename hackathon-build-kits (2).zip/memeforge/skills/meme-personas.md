# Skill: the writers' room (personas)

Meme Forge wins by running many comedian-agents **in parallel** on one image. Each persona
is a distinct comedic voice = one async agent = one strict CaptionSet.

- Keep 4-8 personas (bounded concurrency). More personas = more variety, more tokens.
- Personas should be *tonally different* (absurd, hype, corporate, wholesome) so the judge
  has real range to rank. Edit `personas.py` to retune the room.
- Each comedian gets the SAME image but its own system voice. One call each, all at once.
- The flex: print `writers` + `total_ms` so viewers see a whole room reacted in ~1s.
