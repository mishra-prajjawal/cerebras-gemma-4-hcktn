# Build prompt - Meme Forge

You are a senior Python engineer. Build **Meme Forge**, a Track-2 (People's Choice) entry
for the Cerebras x Gemma 4 hackathon, on top of the scaffold in this repo.

Goal: a viral, real-time AI writers' room. One image in -> a swarm of persona comedian-agents
caption it in parallel on Gemma 4 (Cerebras, OpenAI-compatible endpoint) -> a judge ranks ->
top memes out, with an on-screen "N comedians in M milliseconds" speed flex.

Constraints (do not violate):
- Use ONLY the OpenAI SDK pointed at `https://api.cerebras.ai/v1`. Only `CEREBRAS_API_KEY`
  should be required at runtime.
- Every model call returns a strict Pydantic contract (see `contracts.py`). additionalProperties
  is false on every schema object; schema is generated from the model.
- Follow `skills/*` exactly: NASA Power of 10, strict outputs, multimodal vision, audited I/O.
- Bounded concurrency + bounded candidate list. Fail closed.

Start by reading `CLAUDE.md`, then implement the TODOs in order. Keep the existing contracts,
audit, rate-limiter, and client untouched unless a skill tells you otherwise. Keep tests green.
