# CLAUDE.md - Meme Forge (Track 2: People's Choice)

Persistent guide for the coding agent. Read this first, every session.

## What you are building
A real-time **AI writers' room**: the user drops one image; a swarm of comedian-agents
(each a distinct persona) captions it IN PARALLEL; a judge ranks every caption; the top few
become shareable memes. The whole room reacts in about a second. The novelty = SPEED:
GPUs cannot run a room of agents this fast, so "6 comedians, 1 image, 0.9s" is the hook.

## Non-negotiables
- **Model**: Gemma 4 on Cerebras via the OpenAI-compatible endpoint. Only `CEREBRAS_API_KEY`
  is needed to run; base URL + model id already default in `config.py`/`.env.example`.
- **Every agent edge is a strict Pydantic contract** (`contracts.py`). No free text between
  agents. Strict schema is generated FROM the model (`cerebras_client._schema`).
- **NASA Power of 10** (see `skills/nasa-power-of-10-python.md`): bounded loops, >=2 asserts
  per function, <=60-line functions, no recursion, no unbounded growth, no bare except.
- **Audit every step** via `@audited` (see `skills/async-audit-logging.md`).
- Keep it SFW. Offensive humor kills reshare reach AND fails judging.

## Architecture (already scaffolded)
`personas.py` (the room) -> `agents/comedian.py` (parallel, multimodal) -> `agents/judge.py`
(ranks) -> `pipeline.py` (`forge()` fan-out/fan-in) -> `render.py` (overlay, STUB) ->
`app.py` (CLI). Shared core: `cerebras_client.py`, `rate_limiter.py`, `audit.py`,
`config.py`, `agents/base.py`.

## Your job (TODOs, in order)
1. Implement `render.py` (Pillow impact-text overlay) - this makes output shareable.
2. Build a thin web/mobile UI: drop image -> show the room racing -> show timer + top memes.
3. Add a "roast my desk" live-camera mode for the share loop.
4. Wire the build-in-public clip (tag @Cerebras + @googlegemma in the submission post).
5. Keep `tests/` green; add a fake-client test for `forge()` fan-in.

## Definition of done
`pip install -e .[dev]`, set `CEREBRAS_API_KEY`, `python -m memeforge.app img.jpg "topic"`
prints ranked captions with a real tok/s number. mypy/ruff/pyright clean.
