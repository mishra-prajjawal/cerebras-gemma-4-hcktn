"""Caption overlay (stub). TODO(agent): impact-font top/bottom text via Pillow."""
from __future__ import annotations
from .contracts import RankedCaption


def overlay(jpeg_b64: str, caption: RankedCaption) -> str:
    """Return a new base64 jpeg with the caption burned in.
    Precondition: inputs present. Postcondition: returns a base64 string."""
    assert jpeg_b64, "image required"
    assert caption.text, "caption required"
    raise NotImplementedError("TODO(agent): render impact-text overlay with Pillow")
