# CLAUDE.md — REFLEX (persistent guide for the coding agent)

## Prime directive
Build REFLEX: a real-time, embodied multi-agent build/repair copilot. A webcam watches a
physical workbench; a swarm of agents (Perceptor, StateTracker, ErrorSentinel, Coach,
Narrator) catches a mistake within ~1 second and speaks the fix. Primary model is
**gemma-4-31b on Cerebras**. This targets Track 1 (Multiverse Agents: multi-agent +
multimodal) and the physical-AI Innovation bonus.

## What "done" looks like (24h target)
- Webcam frames sampled at 1-3 fps flow through the agent pipeline.
- ErrorSentinel compares each frame to the current plan step and flags real deviations.
- A live overlay shows tokens/sec + glass-to-glass latency from real usage/time_info.
- A 60-second demo where a planted mistake is caught instantly with a spoken correction.

## The 10 binding rules (NASA Power-of-10, async-Python adaptation)
1 Simple control flow; no recursion/eval/metaprogramming.
2 Every loop has an explicit upper bound (assert it). One supervised event loop + watchdog.
3 No unbounded growth: bounded asyncio.Queue, capped caches.
4 Functions <= 60 lines, single responsibility.
5 >= 2 assertions per function (precondition + postcondition).
6 Smallest possible scope; only frozen config + singletons are global.
7 Check every return; no bare except; typed results + backoff on all I/O.
8 No dynamic attribute/kwargs passthrough across module boundaries.
9 One level of indirection; explicit pipelines, no hidden magic.
10 Zero warnings: mypy --strict, ruff, pyright all clean; pytest green.

## The I/O contract (non-negotiable)
- Every agent edge is a Pydantic model in contracts.py. Model-facing schemas subclass
  Strict (extra="forbid").
- Every process step is wrapped by @audited(agent) (audit.py): one JSON record per step
  with inputs_hash, outputs_hash, latency_ms, status.
- All model calls go through CerebrasClient.structured (cerebras_client.py): rate-limited,
  retried, strict-schema generated FROM the Pydantic model (additionalProperties:false).
- All model calls acquire the RateLimiter (100 RPM / 100K TPM) before firing.

## Locked Cerebras facts
- Only model id: gemma-4-31b. No other model exists this event.
- Multimodal = text + image input -> TEXT output. NO audio. Images via image_url
  (data:image/jpeg;base64,...). Keep images <=768px to respect the 5K sequence cap.
- reasoning_effort defaults to none; use none on the hot path.
- response has .usage and .time_info — use them for the speed overlay.
- Strict structured outputs and strict tools REQUIRE additionalProperties:false (else 422).

## Build order (do in this sequence)
1 config.py + contracts.py compile and validate.
2 Confirm CerebrasClient.structured works against ErrorReport (one real call).
3 frames.py: webcam capture -> downscale -> base64 -> bounded queue.
4 Implement Perceptor, StateTracker, then ErrorSentinel (already drafted), Coach, Narrator.
5 orchestrator.run_loop wires them; skip model calls when StateDelta.changed is False.
6 telemetry overlay + optional gemini_baseline side-by-side (demo-only).
7 Tests green, mypy/ruff/pyright clean. Record the 60s demo.

## Guardrails
- Never invent another model name. Never exceed rate limits. Never log raw image bytes.
- If unsure, keep the hot path minimal and fast — speed is the product.
