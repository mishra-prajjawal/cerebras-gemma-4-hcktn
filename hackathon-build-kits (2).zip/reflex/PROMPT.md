# PROMPT.md — paste this as your first message to the coding agent

You are building REFLEX in this repository. Read CLAUDE.md fully and obey it as binding
law, then read every file under skills/. Do not deviate from the I/O contract or the 10
NASA rules.

Goal: a real-time webcam build-copilot. A multi-agent swarm watches a physical workbench
and catches mistakes within ~1s using gemma-4-31b on Cerebras (multimodal, text+image).

Hard constraints:
- Model id is exactly gemma-4-31b. Multimodal output is TEXT only; no audio.
- Every agent input/output is a Pydantic model in src/reflex/contracts.py.
- Every step is wrapped by @audited; every model call goes through CerebrasClient.structured
  and acquires the RateLimiter first.
- Strict schemas must set additionalProperties:false (generate schema from the model).
- Functions <=60 lines, >=2 assertions each, no bare except, no recursion, bounded loops.
- mypy --strict, ruff, pyright, and pytest must all pass before you call anything done.

Deliver in this order: (1) make config+contracts import and one real ErrorReport call
succeed; (2) frames.py capture; (3) Perceptor, StateTracker, Coach, Narrator (ErrorSentinel
is drafted); (4) orchestrator.run_loop with change-gating; (5) telemetry speed overlay and
optional gemini_baseline; (6) tests + a runnable app.py + a 60s demo path.

When you finish a step, run the test suite and the linters, paste the results, and only
then continue. Ask before adding any dependency not in pyproject.toml.
