# Skill: speed proof & 60s demo (REFLEX)
- Overlay live tokens/sec + glass-to-glass latency from real `usage`+`time_info`.
- Optional split-screen: Gemma-4-on-Cerebras vs a GPU baseline on the SAME frame.
- 60s script: (0-10s) intro + bench, (10-40s) induce a real mistake, agent catches it
  instantly with spoken fix, (40-55s) speed overlay + side-by-side, (55-60s) tagline.
- Show the physical bench on camera = hits the Innovation (physical-AI) bonus.
