# Skill: real-time frame loop (REFLEX)
- Sample webcam at 1-3 fps (NOT every frame). Drop frames if the queue is full.
- Pipeline: capture -> bounded asyncio.Queue -> perceptor -> state_tracker ->
  (error_sentinel) -> coach -> narrator. Skip model calls when StateDelta.changed is False.
- Keep a single supervised event loop + a stop Event + a watchdog task.
- Target glass-to-glass < 1s; this is only possible because Cerebras is ~10-20x GPU.
- Downscale frames to <=768px, JPEG q~70, before base64 to stay under the 5K token cap.
