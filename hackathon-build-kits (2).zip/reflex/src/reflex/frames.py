"""Webcam sampling + JPEG downscale (stub). TODO(agent): wire OpenCV capture."""
from __future__ import annotations
import asyncio
from .contracts import Frame


async def capture(out: asyncio.Queue[Frame], fps: float, stop: asyncio.Event) -> None:
    """Sample the webcam at `fps`, downscale, enqueue Frames. Bounded by `stop`."""
    assert fps > 0, "fps must be positive"
    raise NotImplementedError("TODO(agent): cv2.VideoCapture -> resize<=768 -> b64")
