"""REFLEX entrypoint: starts capture + run_loop + a thin local UI (stub)."""
from __future__ import annotations
import asyncio
from .contracts import PlanStep
from .frames import capture
from .orchestrator import run_loop


async def main(steps: list[PlanStep]) -> None:
    """Wire the pipeline. Precondition: steps non-empty."""
    assert steps, "need a build plan"
    raise NotImplementedError("TODO(agent): build queues, launch capture+run_loop, serve UI")


if __name__ == "__main__":
    asyncio.run(main([]))
