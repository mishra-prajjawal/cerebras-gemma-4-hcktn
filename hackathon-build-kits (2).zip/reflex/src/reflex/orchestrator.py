"""REFLEX hot loop: sample -> perceive -> track -> (sentinel||coach) -> narrate.
Bounded, fail-closed, watchdog-supervised."""
from __future__ import annotations
import asyncio
from .cerebras_client import CerebrasClient
from .config import get_settings
from .contracts import Coaching, ErrorReport, Frame, PlanStep
from .agents.error_sentinel import ErrorSentinel

_MAX_FRAMES = 100_000  # hard upper bound (NASA rule 2)


async def run_loop(frames: asyncio.Queue[Frame], steps: list[PlanStep],
                   stop: asyncio.Event, sink: asyncio.Queue[Coaching | ErrorReport]) -> None:
    """Consume frames until stop. Precondition: steps non-empty.
    Postcondition: never raises into caller; degraded results are emitted, not thrown."""
    assert steps, "plan must have at least one step"
    client = CerebrasClient()
    settings = get_settings()
    step_idx = 0
    for _ in range(_MAX_FRAMES):
        if stop.is_set():
            return
        try:
            frame = await asyncio.wait_for(frames.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue
        sentinel = ErrorSentinel(client, steps[min(step_idx, len(steps) - 1)])
        try:
            report = await sentinel.run(frame)
            await sink.put(report)
            if report.status == "ok":
                step_idx = min(step_idx + 1, len(steps) - 1)
        except Exception:  # noqa: BLE001 - hot loop must survive a bad frame
            continue
    assert False, "frame budget exhausted: investigate runaway loop"
