"""Aggregates live tokens/sec for the speed overlay (stub)."""
from __future__ import annotations


class Telemetry:
    """Rolling mean of tokens/sec + p50 latency. TODO(agent): implement."""

    def observe(self, tokens_per_sec: float, latency_ms: float) -> None:
        assert tokens_per_sec >= 0, "tps must be non-negative"
        raise NotImplementedError("TODO(agent): maintain bounded rolling window")
