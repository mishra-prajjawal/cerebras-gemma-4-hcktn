"""Optional Gemini side-by-side baseline for the demo (stub, demo-only)."""
from __future__ import annotations
from .contracts import ErrorReport, Frame


async def gemini_sentinel(frame: Frame, expectation: str) -> tuple[ErrorReport, float]:
    """Run the SAME prompt on a GPU baseline; return (report, latency_ms) for contrast."""
    raise NotImplementedError("TODO(agent): call Gemini; keep Gemma 4 as primary path")
