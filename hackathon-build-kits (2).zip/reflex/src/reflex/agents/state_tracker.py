"""StateTracker agent (stub). TODO(agent): implement per CLAUDE.md + skills."""
from __future__ import annotations
from ..audit import audited
from ..contracts import Observation, StateDelta
from .base import Agent


class StateTracker(Agent[Observation, StateDelta]):
    name = "state_tracker"

    @audited("state_tracker")
    async def run(self, data: Observation) -> StateDelta:
        """Precondition: typed input. Postcondition: validated StateDelta."""
        assert data is not None, "input required"
        raise NotImplementedError("TODO(agent): implement StateTracker.run")
