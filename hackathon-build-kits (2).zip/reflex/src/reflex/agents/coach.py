"""Coach agent (stub). TODO(agent): implement per CLAUDE.md + skills."""
from __future__ import annotations
from ..audit import audited
from ..contracts import ErrorReport, Coaching
from .base import Agent


class Coach(Agent[ErrorReport, Coaching]):
    name = "coach"

    @audited("coach")
    async def run(self, data: ErrorReport) -> Coaching:
        """Precondition: typed input. Postcondition: validated Coaching."""
        assert data is not None, "input required"
        raise NotImplementedError("TODO(agent): implement Coach.run")
