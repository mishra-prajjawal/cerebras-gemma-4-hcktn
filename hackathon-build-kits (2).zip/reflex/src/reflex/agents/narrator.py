"""Narrator agent (stub). TODO(agent): implement per CLAUDE.md + skills."""
from __future__ import annotations
from ..audit import audited
from ..contracts import Coaching, Coaching
from .base import Agent


class Narrator(Agent[Coaching, Coaching]):
    name = "narrator"

    @audited("narrator")
    async def run(self, data: Coaching) -> Coaching:
        """Precondition: typed input. Postcondition: validated Coaching."""
        assert data is not None, "input required"
        raise NotImplementedError("TODO(agent): implement Narrator.run")
