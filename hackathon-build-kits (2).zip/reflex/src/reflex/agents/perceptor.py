"""Perceptor agent (stub). TODO(agent): implement per CLAUDE.md + skills."""
from __future__ import annotations
from ..audit import audited
from ..contracts import Frame, Observation
from .base import Agent


class Perceptor(Agent[Frame, Observation]):
    name = "perceptor"

    @audited("perceptor")
    async def run(self, data: Frame) -> Observation:
        """Precondition: typed input. Postcondition: validated Observation."""
        assert data is not None, "input required"
        raise NotImplementedError("TODO(agent): implement Perceptor.run")
