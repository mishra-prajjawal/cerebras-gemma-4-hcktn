# Skill: multimodal document ingest

Real enterprise docs arrive as screenshots and scans, not clean text.
- `VisionReader` (stub) turns a screenshot into reviewable text via one Gemma 4 vision call.
- Keep extraction and reviewing as SEPARATE audited steps (extract -> review) for replay.
- For long PDFs, chunk with `ingest.clip` bounds and review chunks in parallel, then merge
  reports before the moderator.
