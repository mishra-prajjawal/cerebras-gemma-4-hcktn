# Skill: grounding and citations (no hallucinated findings)

Enterprises will not trust ungrounded AI. Enforce grounding mechanically:

- Every `Finding.citation` MUST be a verbatim quote from the document.
- `reviewer.py` runs `_grounded()` AFTER the model: any finding whose citation is not an
  exact substring of the source is **dropped**. This is belt-and-suspenders on top of the
  prompt instruction.
- This makes the demo bulletproof: click any finding, see the exact source text.
- Extend it: store char offsets so the UI can highlight the clause in-place.
