# Skill: the adversarial committee

The win for Track 3 is **trust**: many specialist reviewers attack the same document in
parallel, then a chair reconciles. On Cerebras the whole committee returns in seconds.

- Roles live in `roles.py` (Legal, Risk, Finance, Security). Each is one parallel agent.
- Reviewers are adversarial by design: they look for what is WRONG, not a summary.
- The moderator is **fail-closed**: any severity>=4 finding forces overall_risk >= high.
- Show the committee racing (4 reviewers, N seconds) as the enterprise speed flex.
