# Build prompt - Red-Team Committee

You are a senior Python engineer. Build the **Red-Team Committee**, a Track-3 (Enterprise
Impact) entry for the Cerebras x Gemma 4 hackathon, on top of the scaffold in this repo.

Goal: drop an enterprise document; a parallel committee of specialist reviewers (Legal, Risk,
Finance, Security) finds cited issues on Gemma 4 (Cerebras, OpenAI-compatible endpoint); a
chair returns a fail-closed verdict. Every finding cites a verbatim quote from the source.

Constraints (do not violate):
- OpenAI SDK pointed at `https://api.cerebras.ai/v1`; only `CEREBRAS_API_KEY` required at run.
- Strict Pydantic contracts on every edge; schema generated from the model; additionalProperties
  false everywhere.
- Grounding enforced in code (`_grounded`): drop uncited findings. Fail closed in the moderator.
- Follow `skills/*`: NASA Power of 10, strict outputs, multimodal ingest, audited I/O.

Start by reading `CLAUDE.md`, implement the TODOs in order, keep the core untouched unless a
skill says otherwise, and keep tests green.
