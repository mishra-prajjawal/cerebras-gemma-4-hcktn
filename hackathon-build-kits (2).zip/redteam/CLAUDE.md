# CLAUDE.md - Red-Team Committee (Track 3: Enterprise Impact)

Persistent guide for the coding agent. Read this first, every session.

## What you are building
An **instant adversarial review committee** for enterprise documents. Drop a contract,
policy, or screenshot; specialist reviewers (Legal, Risk, Finance, Security) attack it IN
PARALLEL on Gemma 4; each finding is grounded by a verbatim citation; a chair returns a
fail-closed verdict. The enterprise hook = a whole committee reviews in seconds, and every
finding is clickable back to the exact source text (trustworthy, not hallucinated).

## Non-negotiables
- **Model**: Gemma 4 on Cerebras via the OpenAI-compatible endpoint. Only `CEREBRAS_API_KEY`
  needed to run; base URL + model id default in `config.py`/`.env.example`.
- **Grounding is enforced in code**: `reviewer._grounded()` drops any finding whose citation
  is not a verbatim substring of the document. Never relax this.
- **Fail closed**: moderator escalates risk on any severity>=4 finding.
- Strict Pydantic contracts on every edge; NASA Power of 10; audit every step.

## Architecture (already scaffolded)
`roles.py` (the committee) -> `agents/reviewer.py` (parallel, grounded) ->
`agents/moderator.py` (fail-closed verdict) -> `pipeline.py` (`review()`) -> `app.py` (CLI).
`agents/vision_reader.py` (STUB) turns screenshots into reviewable text. Shared core as usual.

## Your job (TODOs, in order)
1. Implement `vision_reader.py` (one Gemma 4 vision call -> extracted text).
2. Add char-offset citations so the UI can highlight clauses in place.
3. Build a web UI: upload doc -> committee races -> verdict + clickable findings.
4. Add an eval set of known-bad contracts; assert the committee catches the planted issues.
5. Keep `tests/` green.

## Definition of done
`pip install -e .[dev]`, set `CEREBRAS_API_KEY`, `python -m redteam.app contract.txt` prints a
grounded verdict with committee timing. mypy/ruff/pyright clean.
