"""Red-Team Committee orchestration: fan out reviewers -> moderator verdict.
Bounded, parallel, fully audited, fail-closed."""
from __future__ import annotations
import asyncio, time
from .cerebras_client import CerebrasClient
from .contracts import DocIn, ModeratorInput, ReviewerInput, ReviewerReport, Verdict
from .ingest import clip
from .roles import ROLES
from .agents.reviewer import Reviewer
from .agents.moderator import Moderator


async def review(doc: DocIn) -> tuple[Verdict, float]:
    """Run the full committee on a document. Precondition: doc has text.
    Postcondition: (validated Verdict, wall_ms). Never raises into the caller for a
    single reviewer failure; only an all-fail or moderator failure propagates."""
    assert isinstance(doc, DocIn), "review needs a DocIn"
    assert doc.text, "this skeleton path requires doc.text (use VisionReader for images)"
    client = CerebrasClient()
    text = clip(doc.text)
    t0 = time.perf_counter()

    reviewer = Reviewer(client)
    inputs = [ReviewerInput(role=name + " - " + brief, doc_text=text)
              for name, brief in ROLES.items()]
    raw = await asyncio.gather(*(reviewer.run(i) for i in inputs),
                               return_exceptions=True)
    reports = [r for r in raw if isinstance(r, ReviewerReport)]
    assert reports, "every reviewer failed; cannot reach a verdict"

    verdict = await Moderator(client).run(ModeratorInput(reports=reports))
    return verdict, round((time.perf_counter() - t0) * 1000, 2)
