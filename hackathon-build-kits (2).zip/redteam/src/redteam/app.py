"""Red-Team entrypoint: text file path -> printed verdict."""
from __future__ import annotations
import asyncio, sys
from .contracts import DocIn
from .pipeline import review


async def main(doc_path: str) -> None:
    """Precondition: a readable text path. Postcondition: prints the verdict."""
    assert doc_path, "document path required"
    with open(doc_path, "r", encoding="utf-8") as fh:
        text = fh.read()
    verdict, ms = await review(DocIn(text=text))
    print("overall_risk=" + verdict.overall_risk + "  committee_ms=" + str(ms))
    print(verdict.summary)
    for b in verdict.blocking_issues:
        print("  - BLOCK: " + b)


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1] if len(sys.argv) > 1 else ""))
