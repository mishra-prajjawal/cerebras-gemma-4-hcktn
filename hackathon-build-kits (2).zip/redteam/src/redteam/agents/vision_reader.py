"""Vision reader (stub): OCR/describe a screenshot into reviewable text.
TODO(agent): implement one multimodal call -> extracted document text."""
from __future__ import annotations
from ..audit import audited
from ..contracts import DocIn, ReviewerInput
from .base import Agent


class VisionReader(Agent[DocIn, ReviewerInput]):
    name = "vision_reader"

    @audited("vision_reader")
    async def run(self, data: DocIn) -> ReviewerInput:
        """Precondition: DocIn with an image. Postcondition: ReviewerInput text."""
        assert isinstance(data, DocIn), "input must be DocIn"
        assert data.jpeg_b64, "vision reader needs an image"
        raise NotImplementedError("TODO(agent): extract text from screenshot via Gemma 4")
